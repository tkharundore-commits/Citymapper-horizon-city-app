# 🚀 Guide d'intégration Citymapper Horizon sur GitHub

## 📋 Table des matières
1. [Préparation des fichiers](#préparation)
2. [Création du repository GitHub](#création-repo)
3. [Upload des fichiers](#upload)
4. [Activation GitHub Pages](#github-pages)
5. [Configuration personnalisée](#configuration)

---

## 1️⃣ Préparation des fichiers {#préparation}

### Structure recommandée du projet :

```
horizon-city-app/
├── index.html          (ton fichier principal)
├── README.md           (documentation)
├── assets/
│   ├── css/
│   │   └── style.css   (optionnel, si tu veux séparer le CSS)
│   ├── js/
│   │   └── app.js      (optionnel, si tu veux séparer le JS)
│   └── images/
│       └── logo.png    (tes images)
└── .gitignore
```

Pour commencer simplement, tu peux utiliser un seul fichier `index.html` (renomme `horizon-city-complete.html` en `index.html`).

---

## 2️⃣ Création du repository GitHub {#création-repo}

### Méthode A : Via l'interface web GitHub (Plus simple)

1. **Aller sur GitHub** : https://github.com
2. **Se connecter** à ton compte (ou créer un compte si tu n'en as pas)
3. **Cliquer sur le bouton "+" en haut à droite** → "New repository"
4. **Configurer le repository** :
   - **Repository name** : `horizon-city-app` (ou le nom de ton choix)
   - **Description** : "Citymapper Horizon - Redéfinir la Mobilité Urbaine"
   - **Public** : Cocher "Public" (pour GitHub Pages gratuit)
   - **Cocher** : "Add a README file"
   - **Cliquer** : "Create repository"

### Méthode B : Via Git en ligne de commande

```bash
# 1. Créer un dossier local
mkdir horizon-city-app
cd horizon-city-app

# 2. Initialiser Git
git init

# 3. Copier ton fichier HTML
# Renommer horizon-city-complete.html en index.html
cp /chemin/vers/horizon-city-complete.html index.html

# 4. Créer un README
echo "# Citymapper Horizon" > README.md
echo "Redéfinir la Mobilité Urbaine" >> README.md

# 5. Premier commit
git add .
git commit -m "Initial commit - Horizon City App"

# 6. Lier au repository GitHub (remplace USERNAME par ton nom d'utilisateur)
git remote add origin https://github.com/USERNAME/horizon-city-app.git

# 7. Push vers GitHub
git branch -M main
git push -u origin main
```

---

## 3️⃣ Upload des fichiers {#upload}

### Option 1 : Upload via l'interface web (PLUS SIMPLE ✅)

1. **Aller sur ton repository** : https://github.com/USERNAME/horizon-city-app
2. **Cliquer sur "Add file"** → "Upload files"
3. **Glisser-déposer** ton fichier `index.html` (renommé depuis horizon-city-complete.html)
4. **Ajouter un message de commit** : "Add Horizon City application"
5. **Cliquer** : "Commit changes"

### Option 2 : Upload via Git Desktop (Interface graphique)

1. **Télécharger GitHub Desktop** : https://desktop.github.com/
2. **Se connecter** à ton compte GitHub
3. **Cloner le repository** : File → Clone repository
4. **Copier ton fichier** index.html dans le dossier cloné
5. **Commit** : Écrire un message et cliquer "Commit to main"
6. **Push** : Cliquer "Push origin"

### Option 3 : Via ligne de commande

```bash
# Dans ton dossier local
git add index.html
git commit -m "Add Horizon City application"
git push origin main
```

---

## 4️⃣ Activation GitHub Pages {#github-pages}

### Étapes détaillées :

1. **Aller dans ton repository** sur GitHub
2. **Cliquer sur "Settings"** (onglet en haut)
3. **Dans le menu de gauche**, cliquer sur **"Pages"**
4. **Sous "Source"** :
   - **Branch** : Sélectionner `main` (ou `master`)
   - **Folder** : Laisser `/ (root)`
5. **Cliquer** : "Save"
6. **Attendre 1-2 minutes** ⏱️

### Ton site sera disponible à :
```
https://USERNAME.github.io/horizon-city-app/
```
(Remplace USERNAME par ton nom d'utilisateur GitHub)

---

## 5️⃣ Configuration personnalisée {#configuration}

### A. Créer un fichier README.md professionnel

```markdown
# 🗺️ Citymapper Horizon

![Horizon Banner](https://via.placeholder.com/1200x300/1C7293/FFFFFF?text=Citymapper+Horizon)

## 🎯 À propos

**Citymapper Horizon** redéfinit la mobilité urbaine en transformant vos trajets quotidiens en aventures de découverte.

### ✨ Fonctionnalités

- 🧭 **Discovery Cards** - Suggestions contextuelles de lieux
- 👥 **Social Flocks** - Navigation collaborative en groupe
- 🤖 **Smart Itineraries** - Planification intelligente par IA
- ⭐ **Citymapper Reviews** - Avis communautaires authentiques

## 🚀 Démo en ligne

👉 [Voir la démo](https://USERNAME.github.io/horizon-city-app/)

## 🛠️ Technologies utilisées

- **Frontend** : HTML5, CSS3, JavaScript (Vanilla)
- **Maps** : Leaflet.js + OpenStreetMap
- **Icons** : Font Awesome
- **Fonts** : Outfit, Inter (Google Fonts)

## 📱 Screenshots

[Ajouter des captures d'écran ici]

## 🤝 Contribuer

Les contributions sont les bienvenues ! N'hésite pas à ouvrir une issue ou une pull request.

## 📄 Licence

MIT License - Voir [LICENSE](LICENSE) pour plus de détails

## 📧 Contact

- Email : contact@horizon-citymapper.com
- Twitter : [@HorizonCity](https://twitter.com)

---

⭐ Si ce projet t'a plu, n'hésite pas à lui donner une étoile !
```

### B. Créer un fichier .gitignore

```
# Fichiers système
.DS_Store
Thumbs.db

# Editeurs
.vscode/
.idea/
*.sublime-*

# Fichiers temporaires
*.log
*.tmp
*~

# Node modules (si tu utilises npm plus tard)
node_modules/
```

### C. Ajouter un domaine personnalisé (Optionnel)

1. **Acheter un domaine** (ex: horizon-city.com sur Namecheap, OVH, etc.)
2. **Dans les paramètres DNS de ton domaine**, ajouter :
   ```
   Type: CNAME
   Name: www
   Value: USERNAME.github.io
   ```
3. **Dans GitHub Pages settings**, ajouter ton domaine personnalisé
4. **Cocher** "Enforce HTTPS"

---

## 🎨 Personnalisation avancée

### Optimiser pour le référencement (SEO)

Ajoute dans le `<head>` de ton index.html :

```html
<!-- SEO Meta Tags -->
<meta name="description" content="Citymapper Horizon - Redéfinir la mobilité urbaine. Découvrez les pépites cachées de Paris sur votre trajet quotidien.">
<meta name="keywords" content="citymapper, horizon, mobilité urbaine, paris, navigation, découverte">
<meta name="author" content="Citymapper Horizon">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="https://USERNAME.github.io/horizon-city-app/">
<meta property="og:title" content="Citymapper Horizon - Redéfinir la Mobilité Urbaine">
<meta property="og:description" content="Découvrez les pépites cachées de votre ville sur chaque trajet">
<meta property="og:image" content="https://USERNAME.github.io/horizon-city-app/assets/og-image.jpg">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="https://USERNAME.github.io/horizon-city-app/">
<meta property="twitter:title" content="Citymapper Horizon">
<meta property="twitter:description" content="Redéfinir la mobilité urbaine">
<meta property="twitter:image" content="https://USERNAME.github.io/horizon-city-app/assets/twitter-image.jpg">

<!-- Favicon -->
<link rel="icon" type="image/png" href="assets/favicon.png">
```

### Ajouter Google Analytics (Optionnel)

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

---

## 📊 Workflow recommandé

### Pour les mises à jour futures :

```bash
# 1. Modifier ton fichier localement
# 2. Tester dans le navigateur (ouvrir index.html)

# 3. Ajouter les modifications
git add .

# 4. Commit avec un message clair
git commit -m "Fix: Correction du responsive mobile"

# 5. Push vers GitHub
git push origin main

# 6. GitHub Pages se met à jour automatiquement en 1-2 minutes
```

---

## 🐛 Dépannage

### Le site ne s'affiche pas ?

1. **Vérifier** que le fichier s'appelle bien `index.html`
2. **Vérifier** que GitHub Pages est activé dans Settings → Pages
3. **Attendre 2-3 minutes** après l'activation
4. **Vider le cache** du navigateur (Ctrl+F5 ou Cmd+Shift+R)

### Erreur 404 ?

- **Vérifier l'URL** : https://USERNAME.github.io/horizon-city-app/
- **Vérifier** que le repository est Public
- **Vérifier** que le fichier index.html est à la racine du repository

### Les cartes ne s'affichent pas ?

- **OpenStreetMap fonctionne sans clé API**, donc ça devrait marcher
- **Vérifier la console** (F12) pour voir les erreurs
- **Vérifier** que tu as une connexion internet

---

## 🎯 Checklist finale

Avant de partager ton site :

- [ ] Le fichier s'appelle `index.html`
- [ ] GitHub Pages est activé
- [ ] Le site est accessible via l'URL
- [ ] Toutes les fonctionnalités marchent
- [ ] Le responsive mobile fonctionne
- [ ] Le README est à jour
- [ ] Les liens sociaux sont corrects
- [ ] Le footer contient tes vraies informations

---

## 🎉 Félicitations !

Ton application Citymapper Horizon est maintenant en ligne ! 

**Prochaines étapes :**
1. Partager le lien sur les réseaux sociaux
2. Demander des retours d'utilisateurs
3. Améliorer progressivement les fonctionnalités
4. Considérer l'ajout d'un backend (Firebase, etc.)

---

## 📚 Ressources utiles

- [Documentation GitHub Pages](https://docs.github.com/en/pages)
- [Leaflet.js Documentation](https://leafletjs.com/reference.html)
- [Font Awesome Icons](https://fontawesome.com/icons)
- [Google Fonts](https://fonts.google.com/)
- [Can I Use](https://caniuse.com/) - Compatibilité navigateurs

---

**Besoin d'aide ?** Ouvre une issue sur GitHub ou contacte-nous !

🌟 **N'oublie pas de donner une étoile au projet si tu l'as apprécié !**
